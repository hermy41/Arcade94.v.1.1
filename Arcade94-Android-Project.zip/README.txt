ARCADE 94 - Android app (WebView wrapper around the game hub)

A) Phone only, free, no PC:
 1. github.com > sign in > New repository > Create.
 2. Add file > Upload files > upload Arcade94-Android-Project.zip (keep it zipped).
 3. Add file > Create new file > name it  .github/workflows/build-apk.yml
    paste the text of build-apk.yml > Commit.
 4. Actions tab > "Build APK" (starts by itself, ~4 min) > Artifacts > Arcade94-APK.
    Unzip it, tap app-debug.apk, allow "install unknown apps".

B) Android Studio: unzip > File > Open > Build > Build APK(s).

The game is app/src/main/assets/index.html. To update, swap that file and rebuild.
First launch needs internet once so the Google Fonts get cached.
